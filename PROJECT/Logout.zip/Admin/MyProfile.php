<form id="form1" name="form1" method="post" action="">
  <table width="200" border="1">
    <table width="200" border="1">
  <tr>
    <td colspan="2"><div align="center"></div></td>
    </tr>
  <tr>
    <td>Name</td>
    <td><form id="form1" name="form1" method="post" action="">
      <label for="txt_name"></label>
      <input type="text" name="txt_name" id="txt_name" />
    </form></td>
  </tr>
  <tr>
    <td>Email</td>
    <td><label for="txt_email"></label>
    <input type="text" name="txt_email" id="txt_email" /></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><form id="form2" name="form2" method="post" action="">
      <label for="txt_address"></label>
      <input type="text" name="txt_address" id="txt_address" />
    </form></td>
  </tr>
  <tr>
    <td>District</td>
    <td><form id="form3" name="form3" method="post" action="">
      <label for="sel_district"></label>
      <select name="sel_district" id="sel_district">
      </select>
    </form></td>
  </tr>
  <tr>
    <td>Place</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
