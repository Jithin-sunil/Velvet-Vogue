<?php 
include('../Assets/connection/connection.php');
include("SessionValidation.php");

if(isset($_POST['btnsubmit']))
{
    $up="update tbl_servicebooking set service_newtime='".$_POST['txttime']."',servicebooking_status='2' where servicebooking_id=".$_GET['rid'];
    if($con->query($up))
    {
        ?>
        <script>
            alert('Updated..')
            window.location="ViewCustomerBooking.php";
        </script>
        <?php
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Time Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: lavender;
            margin: 0;
            padding: 0;
        }

        form {
            margin: 50px auto;
            padding: 20px;
            width: 50%;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid lavender;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f0e5ff;
        }

        td {
            background-color: #faf7ff;
        }

        input[type="time"], input[type="submit"] {
            padding: 8px;
            width: 95%;
            margin: 5px 0;
            border: 1px solid lavender;
            border-radius: 5px;
        }

        input[type="submit"] {
            width: 45%;
            background-color: lavender;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #e0ccee;
        }

        td a {
            color: #5d3a7a;
            text-decoration: none;
            font-weight: bold;
        }

        td a:hover {
            text-decoration: underline;
        }

        div {
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="" method="post">
        <table>
            <tr>
                <td>Time</td>
                <td><input type="time" name="txttime" id="txttime" required></td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <input type="submit" name="btnsubmit" value="Submit">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
