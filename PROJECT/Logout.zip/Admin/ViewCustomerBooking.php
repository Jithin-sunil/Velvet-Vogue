<?php
include('../Assets/connection/connection.php');
session_start();
include("Head.php");
if(isset($_GET['aid']))
{
	$up=" update tbl_servicebooking set servicebooking_status='1' where servicebooking_id=".$_GET['aid'];
	if($con->query($up))
	{
		?>
        <script>
		alert('Accepted');
		window.location="ViewCustomerBooking.php";
		</script>
        <?php
	}
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ViewCustomerBooking</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: lavender;
        color: #333;
    }
    form {
        margin: 50px auto;
        padding: 20px;
        width: 80%;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }
    table, th, td {
        border: 1px solid #ddd;
    }
    th, td {
        padding: 12px;
    }
    th {
        background-color: lavender;
        color: #333;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    a {
        text-decoration: none;
        color: #6a5acd; /* Lavender color */
        font-weight: bold;
    }
    a:hover {
        color: #483d8b; /* Darker lavender */
    }
    td {
        font-size: 14px;
    }
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table>
    <tr>
      <th>SI.NO</th>
      <th>Customer</th>
      <th>Date</th>
      <th>Time</th>
      <th>Service</th>
      <th>Action</th>
    </tr>
    
    <?php
    $i = 0;
    $sel = "select * from tbl_servicebooking b inner join tbl_services s on b.service_id=s.service_id inner join tbl_customerregistration c on b.customer_id=c.customer_id";
    $row = $con->query($sel);
    while ($data = $row->fetch_assoc()) {
        $i++;
    ?>
    <tr>
      <td><?php echo $i ?></td>
      <td><?php echo $data['customer_name'] ?></td>
      <td><?php echo $data['servicebooking_fordate'] ?></td>
      <td><?php echo $data['servicebooking_time'] ?></td>
      <td><?php echo $data['service_name'] ?></td>
      <td>
        <?php
        if ($data['servicebooking_status'] == 1) {
            echo "Approved";
        } elseif ($data['servicebooking_status'] == 2) {
            echo "Reschedule to ".$data['service_newtime']."Wating too User Conformation..";
        } 
        
        elseif ($data['servicebooking_status'] == 3) {
            echo "Verified.. Reschedule to ".$data['service_newtime'];
        } 
        elseif ($data['servicebooking_status'] == 4) {
            echo "Booking Cancled";
        } 
        else {
        ?>
          <a href="ViewCustomerBooking.php?aid=<?php echo $data['servicebooking_id'] ?>">Accept</a>
          <a href="Reschedule.php?rid=<?php echo $data['servicebooking_id'] ?>">Reject</a>
        <?php
        }
        ?>
      </td>
    </tr>
    <?php
    }
    ?>
  </table>
</form>
</body>
</html>
<?php
include("Foot.php");
ob_flush();
?>  


