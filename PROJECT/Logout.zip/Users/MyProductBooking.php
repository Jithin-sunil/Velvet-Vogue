<?php
include('../Assets/connection/connection.php');
include("Head.php");


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>MyProductBooking</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: white;
            color: #333;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 900px;
            margin: 50px auto;
        }

        .table-bordered td,
        .table-bordered th {
            border-color: #F9A392;
        }

        .table th,
        .table td {
            padding: 15px;
            vertical-align: middle;
        }

        .table img {
            border-radius: 5px;
            max-width: 50px;
            height: auto;
        }

        .btn-custom {
    background-color: #F9A392;
    color: #333; /* Darker text for better contrast */
    padding: 8px 20px;
    text-decoration: none;
    border-radius: 5px;
}

.btn-custom:hover {
    background-color: #f7876f;
    color: #333;
}



.btn-custom:hover {
    background-color: #f7876f;
    color: white;
}

        

        .btn-custom:hover {
            background-color: #f7876f;
        }

        .text-center {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <form id="form1" name="form1" method="post" action="">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Photo</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 0;
                    $sel = "select * from tbl_cart c inner join tbl_booking b on c.booking_id=b.booking_id inner join tbl_product p on p.product_id=c.product_id where customer_id=" . $_SESSION['cid'];
                    $row = $con->query($sel);
                    while ($data = $row->fetch_assoc()) {
                        $i++;
                    ?>
                        <tr>
                            <td><?php echo $i ?></td>
                            <td><img src="../Assets/Files/product/<?php echo $data['product_photo'] ?>" /></td>
                            <td><?php echo $data['product_name'] ?></td>
                            <td><?php echo $data['cart_quantity'] ?></td>
                            <td><?php echo $data['product_price'] ?></td>
                            <td><?php echo $data['booking_amount'] ?></td>
                            <td>
                                <?php
                                if ($data['booking_status'] == 1) {
                                    echo "Payment Pending";
                                } else if ($data['booking_status'] == 2) {
                                    echo "Payment Completed";
                                } else if ($data['booking_status'] == 3) {
                                    echo "Product Packed";
                                } else if ($data['booking_status'] == 4) {
                                    echo "Product Shipped";
                                } else if ($data['booking_status'] == 5) {
                                    echo "Product Received";
                                ?>
                                    <br>
                                    <a href="Rating.php?pid=<?php echo $data['product_id'] ?>" class="btn-custom me-2">Rating</a>
                                    <a href="PostComplaint.php?pid=<?php echo $data['product_id'] ?>" class="btn-custom">Complaint</a>
                                <?php
                                }
                                ?>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>


<?php
include("Foot.php");
ob_flush();
?>  

