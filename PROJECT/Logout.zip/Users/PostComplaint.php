<?php
include('../Assets/connection/connection.php');
ob_start();
include("Head.php");
if(isset($_POST["btn_submit"]))
{
	$product=$_GET['pid'];
	$photo=$_FILES['sel_file']['name'];
	$temp=$_FILES['sel_file']['tmp_name'];
	move_uploaded_file($temp,'../Assets/Files/product/'.$photo);
	$title=$_POST["txt_title"];
	$discreption=$_POST["txt_discreption"];
	
	$insqry="insert into tbl_complaint(complaint_title,complaint_file,complaint_descrption,complaint_date,product_id,customer_id)values('".$title."','".$photo."','".$discreption."',curdate(),'".$product."','".$_SESSION['cid']."')";
     if($con->query($insqry))
	{
		?>
        <script>
		alert('complaint posted');
		window.location="PostComplaint.php";
		</script>
        <?php
	
	}
}

	
	?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Post Complaints</title>
</head>

<body>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <div align="center">
    <table width="200" border="1">
      <tr>
        <td>Title</td>
        <td><label for="txt_title"></label>
        <input type="text" name="txt_title" id="txt_title" /></td>
      </tr>
      <tr>
        <td>File</td>
        <td><label for="sel_file"></label>
          <input type="file" name="sel_file" id="sel_file" />
        </td>
      </tr>
      <tr>
        <td>Description</td>
        <td><label for="txt_descreption"></label>
          <label for="txt_discreption"></label>
          <textarea name="txt_discreption" id="txt_discreption" cols="45" rows="5"></textarea></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center">
          <input type="submit" name="btn_submit" id="btn_submit" value="Submit" />
        </div></td>
      </tr>
      <tr>
       
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</form>
</body>
</html>
<?php
include("Foot.php");
ob_flush();
?>  